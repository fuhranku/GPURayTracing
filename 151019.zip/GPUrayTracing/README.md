GPU RAY Tracing project.

UCV 2019